import { useGLTF } from '@react-three/drei'
import { useBox } from '@react-three/cannon'
import { useFrame } from '@react-three/fiber'
import { useRef } from 'react'

export default function Car({ position, controls }) {
  const { scene } = useGLTF('/models/bmw_m4_competition_m_package.glb')
  const keys = useRef({})

  window.addEventListener('keydown', e => keys.current[e.key.toLowerCase()] = true)
  window.addEventListener('keyup', e => keys.current[e.key.toLowerCase()] = false)

  const [ref, api] = useBox(() => ({
    mass: 5,
    position,
    args: [2.2, 1, 4.5]
  }))

  useFrame(() => {
    const speed = 12
    const boost = 25

    if (keys.current[controls.forward]) api.velocity.set(0, 0, -speed)
    if (keys.current[controls.backward]) api.velocity.set(0, 0, speed)
    if (keys.current[controls.left]) api.angularVelocity.set(0, 2, 0)
    if (keys.current[controls.right]) api.angularVelocity.set(0, -2, 0)
    if (keys.current[controls.boost]) api.applyImpulse([0, 0, -boost], [0, 0, 0])
  })

  return <primitive ref={ref} object={scene.clone()} scale={1.2} />
}
