import { usePlane } from '@react-three/cannon'

export default function Arena() {
  const [ref] = usePlane(() => ({
    rotation: [-Math.PI / 2, 0, 0]
  }))

  return (
    <mesh ref={ref} receiveShadow>
      <planeGeometry args={[120, 80]} />
      <meshStandardMaterial color="green" />
    </mesh>
  )
}
