import { useSphere } from '@react-three/cannon'

export default function Ball() {
  const [ref] = useSphere(() => ({
    mass: 1,
    position: [0, 2, 0],
    args: [1]
  }))

  return (
    <mesh ref={ref} castShadow>
      <sphereGeometry args={[1, 32, 32]} />
      <meshStandardMaterial color="white" />
    </mesh>
  )
}
