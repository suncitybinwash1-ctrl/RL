import { Canvas } from '@react-three/fiber'
import { Physics } from '@react-three/cannon'
import { OrbitControls } from '@react-three/drei'
import Arena from './Arena'
import Ball from './Ball'
import Car from './Car'
import HUD from './HUD'

export default function Game() {
  return (
    <>
      <HUD />
      <Canvas shadows camera={{ position: [0, 12, 18], fov: 60 }}>
        <ambientLight intensity={1.5} />
        <directionalLight castShadow position={[10, 20, 10]} intensity={2} />

        <Physics gravity={[0, -9.81, 0]}>
          <Arena />
          <Ball />

          <Car position={[0, 1, 6]} controls={{ forward: 'w', backward: 's', left: 'a', right: 'd', boost: 'shift' }} />

          <Car position={[0, 1, -6]} controls={{ forward: 'arrowup', backward: 'arrowdown', left: 'arrowleft', right: 'arrowright', boost: '/' }} />
        </Physics>

        <OrbitControls />
      </Canvas>
    </>
  )
}
