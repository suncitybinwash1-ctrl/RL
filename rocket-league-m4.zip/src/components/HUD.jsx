export default function HUD() {
  return (
    <div style={{
      position: 'absolute',
      top: 20,
      left: 20,
      color: 'white',
      fontSize: 24,
      zIndex: 100
    }}>
      Rocket League BMW M4 1v1
    </div>
  )
}
