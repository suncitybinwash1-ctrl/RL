import Game from './components/Game'
import './styles/styles.css'

export default function App() {
  return <Game />
}
